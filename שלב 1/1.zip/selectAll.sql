select comid, rank, numofunitcom
from commander

select DOCID, LICENSE_NUMBER, SENIORITY, NUMOFUNITDOC
from doctor

select PARID, LICENSE_NUMBER, SENIORITY, NUMOFUNITPAR
from paramedic

select EQUID, EXPERTISE, NUMOFUNITEQI
from EQUIPMENT_MANAGER

select LICENSE_NUMBER, DRID, NUMOFUNITDRI
from driver

select MEDID, SENIORITY, NUMOFUNITMED
from medic
